<div class="card-title">
    <div class="d-flex align-items-center position-relative my-1">
        <span class="svg-icon svg-icon-1 position-absolute ms-6">
            <span data-feather="search"></span>
        </span>
        <input type="text" data-kt-customer-table-filter="search"
               id="data-table-search"
               class="form-control form-control-solid w-250px ps-15"
               placeholder="{{ $search_place_holder }}"/>
    </div>
</div>
