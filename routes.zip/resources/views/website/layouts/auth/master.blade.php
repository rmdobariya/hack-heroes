<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @php
        $logo = DB::table('site_settings')->where('setting_key','LOGO_IMG')->first()->setting_value;
        $fav = DB::table('site_settings')->where('setting_key','FAVICON_IMG')->first()->setting_value;
        $terms_condition = DB::table('site_settings')->where('setting_key','TERMS_CONDITION')->first()->setting_value;
        $privacy_policy = DB::table('site_settings')->where('setting_key','PRIVACY_POLICY')->first()->setting_value;
    @endphp
    @if(!is_null($fav))
        <link rel="icon" href="{{asset($fav)}}" type="image/x-icon">
        <link rel="shortcut icon" href="{{asset($fav)}}"
              type="image/x-icon">
    @else
        <link rel="icon" href="{{asset('assets/web/images/logo.png')}}" type="image/x-icon">
        <link rel="shortcut icon" href="{{asset('assets/web/images/logo.png')}}"
              type="image/x-icon">
    @endif
    @include('website.layouts.auth.css')
</head>
<body>
@include('website.layouts.auth.header')
@yield('content')
@include('website.layouts.auth.footer')
@include('website.layouts.auth.script')
@yield('custom-script')
</body>
</html>
