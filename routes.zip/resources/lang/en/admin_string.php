<?php
return array(
    'common_name' => 'Name',
    'create' => 'Create',
);
