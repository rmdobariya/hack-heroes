<?php
return array (
    'common_name' => 'اسم',
);
