<div class="input-box attribute-row attribute-row-{{$rowNo}}">
    <div class="form-check">
        <input class="form-check-input" type="checkbox" name="create_plan[{{$rowNo}}]"
               id="create_plan_{{$rowNo}}">
        <input type="text" name="child[{{$rowNo}}]" id="child_{{$rowNo}}" style="border: none">
        <label class="form-check-label" for="create_plan_{{$rowNo}}">
        </label>
    </div>
</div>
