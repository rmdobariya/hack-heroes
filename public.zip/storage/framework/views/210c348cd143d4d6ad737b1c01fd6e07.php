<?php $__env->startComponent('mail::message'); ?>
    # Hello <?php echo e($details['name']); ?>,
    Password Reset
    <?php $__env->startComponent('mail::button', ['url' => $details['actionUrl']]); ?>
        Reset Button
    <?php echo $__env->renderComponent(); ?>
    Thanks
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\admin-template\resources\views/emails/resetPassword.blade.php ENDPATH**/ ?>