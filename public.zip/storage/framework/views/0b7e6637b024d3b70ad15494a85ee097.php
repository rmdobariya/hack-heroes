<div class="card-toolbar">
    <div class="w-100 mw-150px">
        <select class="form-select form-select-solid status-filter min-w-100px"
                id="status"
                data-control="select2"
                data-hide-search="true"
                data-placeholder="Status"
                data-kt-ecommerce-product-filter="<?php echo e(trans('vendor_string.common_status')); ?>">
            <option></option>
            <option value="all"><?php echo e(trans('vendor_string.all')); ?></option>
            <option value="active"><?php echo e(trans('vendor_string.common_status_active')); ?></option>
            <option value="inActive"><?php echo e(trans('vendor_string.common_status_inActive')); ?></option>
        </select>
    </div>
</div>
<?php /**PATH C:\laragon\www\HackHeroes\resources\views/admin/layouts2/components/status-active-inactive.blade.php ENDPATH**/ ?>