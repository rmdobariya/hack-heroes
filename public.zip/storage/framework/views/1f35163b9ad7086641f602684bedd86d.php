<?php echo $__env->yieldContent('css'); ?>

<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700"/>
<link href="<?php echo e(asset('assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(asset('assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css"/>

<script src="https://unpkg.com/feather-icons"></script>
<?php /**PATH C:\laragon\www\HackHeroes\resources\views/admin/layouts2/authentication/css.blade.php ENDPATH**/ ?>