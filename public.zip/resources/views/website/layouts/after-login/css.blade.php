<link href="{{ asset('assets/plugins/global/plugins.bundle.css') }}" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
<link rel='stylesheet' href='https://unpkg.com/aos@2.3.0/dist/aos.css'>
<link rel="stylesheet" type="text/css" href="{{asset('assets/web/css/bootstrap.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('assets/web/css/style.css')}}">
