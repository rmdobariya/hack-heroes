<input type="text" name="name[{{$rowNo}}]"  placeholder="Child’s Name"
       class="form-control attribute-row-{{$rowNo}}" required>
